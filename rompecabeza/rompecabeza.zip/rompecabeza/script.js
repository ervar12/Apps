let image;
let pieces = [];
let emptyPieceIndex;
const puzzleSize = 3; // Cambia esto para establecer el tamaño del rompecabezas (3x3, 4x4, etc.)

function createPuzzle(image) {
    const pieceWidth = image.width / puzzleSize;
    const pieceHeight = image.height / puzzleSize;

    pieces = [];
    emptyPieceIndex = puzzleSize * puzzleSize - 1;

    const container = document.getElementById('puzzleContainer');
    container.innerHTML = '';
    
    for (let i = 0; i < puzzleSize * puzzleSize; i++) {
        const row = Math.floor(i / puzzleSize);
        const col = i % puzzleSize;

        const piece = document.createElement('div');
        piece.className = 'puzzlePiece';
        piece.style.backgroundImage = `url(${image.src})`;
        piece.style.backgroundSize = `${image.width}px ${image.height}px`;
        piece.style.backgroundPosition = `-${col * pieceWidth}px -${row * pieceHeight}px`;
        piece.style.width = pieceWidth + 'px';
        piece.style.height = pieceHeight + 'px';
        piece.style.top = Math.floor(i / puzzleSize) * pieceHeight + 'px';
        piece.style.left = (i % puzzleSize) * pieceWidth + 'px';
        piece.dataset.index = i;

        if (i === emptyPieceIndex) {
            piece.style.visibility = 'hidden';
        } else {
            piece.draggable = true;
            piece.addEventListener('dragstart', dragStart);
            piece.addEventListener('dragover', dragOver);
            piece.addEventListener('drop', drop);
        }

        pieces.push(piece);
        container.appendChild(piece);
    }
}

function dragStart(e) {
    e.dataTransfer.setData('text', e.target.id);
}

function dragOver(e) {
    e.preventDefault();
}

function drop(e) {
    e.preventDefault();
    const data = e.dataTransfer.getData('text');
    const draggedPiece = document.getElementById(data);
    const emptyPiece = pieces[emptyPieceIndex];

    if (isAdjacent(Number(draggedPiece.dataset.index), emptyPieceIndex)) {
        swapPieces(Number(draggedPiece.dataset.index), emptyPieceIndex);
        emptyPieceIndex = Number(draggedPiece.dataset.index);

        if (isSolved()) {
            showMessagePopup("¡Felicidades, ganaste!");
        }
    }
}

function isAdjacent(index1, index2) {
    const row1 = Math.floor(index1 / puzzleSize);
    const col1 = index1 % puzzleSize;
    const row2 = Math.floor(index2 / puzzleSize);
    const col2 = index2 % puzzleSize;

    return Math.abs(row1 - row2) + Math.abs(col1 - col2) === 1;
}

function swapPieces(index1, index2) {
    const temp = pieces[index1];
    pieces[index1] = pieces[index2];
    pieces[index2] = temp;

    const container = document.getElementById('puzzleContainer');
    container.innerHTML = '';
    pieces.forEach(piece => container.appendChild(piece));
}

function isSolved() {
    for (let i = 0; i < pieces.length; i++) {
        const row = Math.floor(i / puzzleSize);
        const col = i % puzzleSize;

        const expectedBackgroundPositionX = -col * (image.width / puzzleSize);
        const expectedBackgroundPositionY = -row * (image.height / puzzleSize);

        if (pieces[i].style.backgroundPosition !== `${expectedBackgroundPositionX}px ${expectedBackgroundPositionY}px`) {
            return false;
        }
    }
    return true;
}

function showMessagePopup(message) {
    const popup = document.getElementById('messagePopup');
    popup.textContent = message;
    popup.style.display = 'block';

    setTimeout(() => {
        popup.style.display = 'none';
    }, 2000);
}

document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = function(e) {
        image = new Image();
        image.src = e.target.result;
        image.onload = function() {
            createPuzzle(image);
        };
    };
    reader.readAsDataURL(file);
});
