let users = [];

function addUser() {
  const userName = document.getElementById("userName").value.trim();
  if (userName !== "") {
    users.push(userName);
    createTable();
    document.getElementById("userName").value = "";
  }
}

/*function createTable() {
  const table = document.getElementById("numberTable");
  table.innerHTML = ""; // Clear existing table

  // Determine the maximum number of cells needed
  let maxCells = 10; // Default for header row
  users.forEach(user => {
    maxCells = Math.max(maxCells, user.length);
  });

  // Add header row with the maximum number of cells
  const headerRow = table.insertRow();
  headerRow.insertCell().appendChild(document.createTextNode("Usuario"));
  for (let i = 1; i <= maxCells; i++) {
    headerRow.insertCell().appendChild(document.createTextNode(i));
  }

  // Add user rows with the same number of cells as the header row
  users.forEach(user => {
    const userRow = table.insertRow();
    const userCell = userRow.insertCell();
    userCell.appendChild(document.createTextNode(user));
    for (let i = 1; i <= maxCells; i++) {
      const cell = userRow.insertCell();
      cell.contentEditable = true;
      cell.dataset.user = user;
      cell.dataset.total = 0;
    }
    const totalCell = userRow.insertCell(); // Cell for user total
    totalCell.dataset.user = user;
  });

  // Add additional columns as requested
  for (let i = 1; i <= maxCells; i++) {
    const headerCell = headerRow.insertCell();
    headerCell.appendChild(document.createTextNode(i));

    // Add rows for numbers 1 to 10
    for (let j = 0; j < table.rows.length - 1; j++) {
      const cell = table.rows[j].insertCell();
      cell.contentEditable = true;
      cell.dataset.user = table.rows[j].cells[0].innerText;
      cell.dataset.total = 0;
    }
  }

  for (let i = 1; i <= 3; i++) {
    const headerCell = headerRow.insertCell();
    headerCell.appendChild(document.createTextNode(10));

    // Add rows for number 10
    for (let j = 0; j < table.rows.length - 1; j++) {
      const cell = table.rows[j].insertCell();
      cell.contentEditable = true;
      cell.dataset.user = table.rows[j].cells[0].innerText;
      cell.dataset.total = 0;
    }
  }

  for (let i = 9; i >= 1; i--) {
    const headerCell = headerRow.insertCell();
    headerCell.appendChild(document.createTextNode(i));

    // Add rows for numbers 9 to 1
    for (let j = 0; j < table.rows.length - 1; j++) {
      const cell = table.rows[j].insertCell();
      cell.contentEditable = true;
      cell.dataset.user = table.rows[j].cells[0].innerText;
      cell.dataset.total = 0;
    }
  }

  const sumPartialButton = document.createElement("button");
  sumPartialButton.textContent = "Suma Parcial";
  sumPartialButton.onclick = calculatePartialSum;
  table.parentNode.insertBefore(sumPartialButton, table.nextSibling);
}*/

function createTable() {
    const table = document.getElementById("numberTable");
    table.innerHTML = ""; // Clear existing table
  
    // Determine the maximum number of cells needed
    let maxCells = 10; // Default for header row
    users.forEach(user => {
      maxCells = Math.max(maxCells, user.length);
    });
  
    // Add header row with the maximum number of cells
    const headerRow = table.insertRow();
    headerRow.insertCell().appendChild(document.createTextNode("Usuario"));
    for (let i = 1; i <= maxCells; i++) {
      headerRow.insertCell().appendChild(document.createTextNode(i));
    }
  
    // Add user rows with the same number of cells as the header row
    users.forEach(user => {
      const userRow = table.insertRow();
      const userCell = userRow.insertCell();
      userCell.appendChild(document.createTextNode(user));
      for (let i = 1; i <= maxCells; i++) {
        const cell = userRow.insertCell();
        cell.contentEditable = true;
        cell.dataset.user = user;
        cell.dataset.total = 0;
      }
      const totalCell = userRow.insertCell(); // Cell for user total
      totalCell.dataset.user = user;
    });
  
    /*// Add additional columns as requested
    for (let i = 1; i <= maxCells; i++) {
      const headerCell = headerRow.insertCell();
      headerCell.appendChild(document.createTextNode(i));
  
      // Add rows for numbers 1 to 10
      for (let j = 0; j < users.length; j++) {
        const cell = table.rows[j + 1].insertCell();
        cell.contentEditable = true;
        cell.dataset.user = table.rows[j + 1].cells[0].innerText;
        cell.dataset.total = 0;
      }
    }*/
  
    for (let i = 1; i <= 3; i++) {
      const headerCell = headerRow.insertCell();
      headerCell.appendChild(document.createTextNode(10));
  
      // Add rows for number 10
      for (let j = 0; j < users.length; j++) {
        const cell = table.rows[j + 1].insertCell();
        cell.contentEditable = true;
        cell.dataset.user = table.rows[j + 1].cells[0].innerText;
        cell.dataset.total = 0;
      }
    }
  
    for (let i = 9; i >= 1; i--) {
      const headerCell = headerRow.insertCell();
      headerCell.appendChild(document.createTextNode(i));
  
      // Add rows for numbers 9 to 1
      for (let j = 0; j < users.length; j++) {
        const cell = table.rows[j + 1].insertCell();
        cell.contentEditable = true;
        cell.dataset.user = table.rows[j + 1].cells[0].innerText;
        cell.dataset.total = 0;
      }
    }
  
    const sumPartialButton = document.createElement("button");
    sumPartialButton.textContent = "Suma Parcial";
    sumPartialButton.onclick = calculatePartialSum;
    table.parentNode.insertBefore(sumPartialButton, table.nextSibling);
  }
  

function calculatePartialSum() {
  const table = document.getElementById("numberTable");
  const rows = table.rows;

  for (let i = 1; i < rows.length; i++) {
    let sum = 0;
    const cells = rows[i].cells;
    for (let j = 1; j < cells.length - 1; j++) {
      const value = parseInt(cells[j].innerText) || 0;
      sum += value;
    }
    cells[cells.length - 1].innerText = "Total: " + sum;
  }
}
