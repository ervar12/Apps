/*function createDropdown(cell) {
    const dropdown = document.createElement("select");
    const options = ["", -3, -6, -9, "Otro", 10, 13, 16, 19, ""];
  
    options.forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      dropdown.appendChild(option);
    });
  
    dropdown.onchange = () => {
      if (dropdown.value === "Otro" || dropdown.value === "") {
        cell.innerHTML = " ";
        cell.contentEditable = true;
        cell.focus();
      } else {
        cell.textContent = dropdown.value;
        cell.contentEditable = true;
      }
      cell.removeChild(dropdown);
    };
  
    cell.innerHTML = "";
    cell.appendChild(dropdown);
    dropdown.focus();
  }
  */
  function createDropdown(cell) {
    const dropdown = document.createElement("select");
    const options = ["", -3, -6, -9, "Otro", 10, 13, 16, 19, ""];

    options.forEach(value => {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = value;
        dropdown.appendChild(option);
    });

    dropdown.onchange = () => {
        const selectedValue = dropdown.value;
        cell.removeChild(dropdown);

        if (selectedValue === "Otro" || selectedValue === "") {
            cell.innerHTML = " ";
            cell.contentEditable = true;

            // Usamos un timeout corto para asegurar que el contentEditable sea aplicado antes de enfocar
            setTimeout(() => {
                cell.focus();
            }, 0);
        } else {
            cell.textContent = selectedValue;
            cell.contentEditable = false; // Establecemos false si no es "Otro"
        }
    };

    let clickTimeout;
    cell.onclick = () => {
        clearTimeout(clickTimeout);
        clickTimeout = setTimeout(() => {
            // Limpiamos la celda y agregamos el dropdown solo si es un solo clic
            cell.innerHTML = "";
            cell.appendChild(dropdown);
            dropdown.focus();
        }, 250); // Retardo para distinguir entre clic simple y doble clic
    };

    cell.ondblclick = () => {
        clearTimeout(clickTimeout);
        cell.contentEditable = true;
        setTimeout(() => {
            cell.focus();
        }, 0);
    };
}

// Ejemplo de cómo aplicar la función createDropdown a una celda
document.addEventListener('DOMContentLoaded', () => {
    const cell = document.getElementById('myCell');
    createDropdown(cell);
});


  let users = [];
  let buttonCreated = false;
  
  function startProgram() {
    const numberOfHands = parseInt(prompt("Cuántas manos jugamos AMEO:"));
    if (isNaN(numberOfHands) || numberOfHands <= 0) {
      alert("SOS BOLUDO???!!!");
      return;
    }
    createTable(numberOfHands);
  }
  
  function addUser() {
    const userName = document.getElementById("userName").value.trim();
    if (userName !== "") {
      users.push(userName);
      createTable();
      document.getElementById("userName").value = "";
    }
  }
  
  function createTable(numberOfHands) {
    const table = document.getElementById("numberTable");
    table.innerHTML = ""; // Clear existing table
  
    if (numberOfHands === 0) {
      console.error("El número de manos no puede ser 0.");
      return;
    }
  
    /*// Creación de la fila de encabezado
    const headerRow = table.insertRow();
    headerRow.insertCell().appendChild(document.createTextNode("Jugador"));
    for (let i = 1; i <= numberOfHands /2 ; i++) {
      const headerCell = headerRow.insertCell();
      headerCell.appendChild(document.createTextNode(i));
    
      for (let i = 5; i <= numberOfHands /2 ; i--) {
      const headerCell = headerRow.insertCell();
      headerCell.appendChild(document.createTextNode(i));
    }
  }
    headerRow.insertCell().appendChild(document.createTextNode("Total"));*/

    // Creación de la fila de encabezado
const headerRow = table.insertRow();
headerRow.insertCell().appendChild(document.createTextNode("Jugador"));

// Primer bucle: desde 1 hasta la mitad de numberOfHands
const halfHands = numberOfHands / 2;
for (let i = 1; i <= halfHands; i++) {
  const headerCell = headerRow.insertCell();
  headerCell.appendChild(document.createTextNode(i));
}

// Inserta una celda adicional con el valor de la mitad de numberOfHands
headerRow.insertCell().appendChild(document.createTextNode(halfHands));

// Segundo bucle: desde la mitad de numberOfHands decreciendo hasta 1
for (let i = halfHands; i >= 1; i--) {
  const headerCell = headerRow.insertCell();
  headerCell.appendChild(document.createTextNode(i));
}

// Inserta una celda adicional con el valor de la mitad de numberOfHands
headerRow.insertCell().appendChild(document.createTextNode(halfHands));

headerRow.insertCell().appendChild(document.createTextNode("Total"));

    // Creación de filas de usuarios
    users.forEach(user => {
      const userRow = table.insertRow();
      const userCell = userRow.insertCell();
      userCell.appendChild(document.createTextNode(user));
      for (let i = 1; i <= numberOfHands +2; i++) {
        const cell = userRow.insertCell();
        cell.contentEditable = true;
        cell.dataset.user = user;
        cell.dataset.total = 0;
        cell.onclick = () => createDropdown(cell);
      }
      const totalCell = userRow.insertCell(); // Celda para el total del usuario
      totalCell.dataset.user = numberOfHands;
    });
  
    if (!buttonCreated) {
      const enviarPorWhatsApp = document.createElement("button");
      const sumPartialButton = document.createElement("button");
      const scrollRightButton = document.createElement("button");
  
      enviarPorWhatsApp.textContent = "Manda x guasap!";
      enviarPorWhatsApp.onclick = enviarPorWhatsApp1;
      enviarPorWhatsApp.classList.add("whatsapp-btn");
      table.parentNode.appendChild(enviarPorWhatsApp);
  
      sumPartialButton.textContent = "Suma Parcial";
      sumPartialButton.onclick = calculatePartialSum;
      sumPartialButton.classList.add("modern-button");
      table.parentNode.insertBefore(sumPartialButton, table.nextSibling);
  
      scrollRightButton.textContent = "Ir a resultados";
      scrollRightButton.onclick = function() {
          window.scrollTo(document.body.scrollWidth, 0);
      };
      scrollRightButton.classList.add("scroll-right-button");
      table.parentNode.appendChild(scrollRightButton, table.nextSibling);
  
      const buttonContainer = document.createElement("div");
      buttonContainer.classList.add("button-container");
      buttonContainer.appendChild(enviarPorWhatsApp);
      buttonContainer.appendChild(sumPartialButton);
      buttonContainer.appendChild(scrollRightButton);
  
      table.parentNode.appendChild(buttonContainer);
      buttonCreated = true;
    }
  }
  
  /*function calculatePartialSum() {
    const table = document.getElementById("numberTable");
    const rows = table.rows;
    for (let i = 1; i < rows.length; i++) {
      let sum = 0;
      for (let j = 1; j < rows[i].cells.length - 1; j++) {
        const value = parseFloat(rows[i].cells[j].textContent);
        if (!isNaN(value)) {
          sum += value;
        }
      }
      rows[i].cells[rows[i].cells.length - 1].textContent = sum;
    }
  }*/
  
  function calculatePartialSum() {
    const table = document.getElementById("numberTable");
    const rows = table.rows;
  
    for (let i = 1; i < rows.length; i++) {
      let sum = 0;
      const cells = rows[i].cells;
      // Obtener el nombre de usuario de la primera celda de la fila
      const userName = cells[0].innerText;
  
      for (let j = 1; j < cells.length - 1; j++) {
        const value = parseInt(cells[j].innerText) || 0;
        sum += value;
      }
      cells[cells.length - 1].innerText = "El " + userName + " suma: " + sum;
    }
    
    // Obtener la última celda de la última fila
    const lastRow = rows[rows.length - 1];
    const lastCell = lastRow.cells[lastRow.cells.length - 1];
    
    // Establecer el foco en la última celda de la última fila
    lastCell.focus();
  }



  function enviarPorWhatsApp1() {
    // Implementar funcionalidad para enviar resultados por WhatsApp
  }
  