//<!--Autor: Ervar Luis Molina  fecha 20/5/2024-->

function calculateScore() {
    const age = parseInt(document.getElementById('age').value);
    const shock = parseInt(document.getElementById('shock').value);
    const comorbidity = parseInt(document.getElementById('comorbidity').value);
    const diagnosis = parseInt(document.getElementById('diagnosis').value);
    const eesr = parseInt(document.getElementById('eesr').value);
  
    const score = age + shock + comorbidity + diagnosis + eesr;
    document.getElementById('score').innerText = score;
  }
  
  function calculateGlasgow() {
    const urea = parseInt(document.getElementById('urea').value);
    const hemoglobinMale = parseInt(document.getElementById('hemoglobinMale').value);
    const hemoglobinFemale = parseInt(document.getElementById('hemoglobinFemale').value);
    const systolicBP = parseInt(document.getElementById('systolicBP').value);
    const otherMarkers = parseInt(document.getElementById('otherMarkers').value);
  
    const score2 = urea + hemoglobinMale + hemoglobinFemale + systolicBP + otherMarkers;
    document.getElementById('score2').innerText = score2;
  }
  